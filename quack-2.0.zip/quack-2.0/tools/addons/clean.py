#!/usr/bin/env python3

import os

os.system("clear")
