#!/usr/bin/env python3

import os

print("")
os.system("cat banner/banner.txt")
print("")
